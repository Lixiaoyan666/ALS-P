
source("functions1.R")

N=100000
rho=0.5
case=1 #2,3
error.type=1#2,3,4
S=1000
r0=200
varrho=0.5
tau=0.3#0.5,0.7
alpha.case=1#2,3

Data = DGPfunB(N=N, rho=rho, case=case, error.type)
x = Data$X
y = Data$Y
beta = Data$beta

p <- ncol(x)

if(alpha.case==1){
  alpha <- diag(rep(1,p))
}else{
  if(alpha.case==2){
    alpha <- rep(1,p)
  }else{
    alpha <- c(1,rep(0,p-1))  
  }
} 

subsize = c(200,400,600,800,1000)
fit.als_g = gals.newton(x,y,tau,1,1)
ct_g = rep(fit.als_g$ct,length(subsize))

cores <- detectCores()-2
cl <- makeCluster(cores)
registerDoParallel(cl, cores=cores)
sim.res = foreach(i=1:S, .packages =c("matrixStats", "MASS", "glmnet","Runuran","quantreg")) %dopar%
  {
    subsize = c(200,400,600,800,1000)
    mse_u =  mse_lp = mse_lev = mse_qr_dlp = mse_wals_lp= rep(0,length(subsize))
    ct_u =  ct_lp = ct_lev = ct_qr_dlp = ct_wals_lp = rep(0,length(subsize))
    
    for (rr in 1:length(subsize)) {
      
      fit.als_u = als_u(x,y,r=r0+subsize[rr],tau)
      beta_u = fit.als_u$beta
      mse_u[rr] = norm(beta_u-beta, "2")^2 
      ct_u[rr] = fit.als_u$ct
      
      fit.als_lp = als_dlp(x,y,r0,r=subsize[rr],tau,varrho,alpha.case)
      beta_lp = fit.als_lp$beta
      mse_lp[rr] = norm(beta_lp-beta, "2")^2
      ct_lp[rr] = fit.als_lp$ct
      
      fit.als_lev = als_lev(x,y,r=r0+subsize[rr],tau,varrho=0)
      beta_lev = fit.als_lev$beta
      mse_lev[rr] = norm(beta_lev-beta, "2")^2
      ct_lev[rr] = fit.als_lev$ct
      
      fit.qr_dlp = qr_dlp(x,y,r0,r=subsize[rr],tau,varrho=0,alpha.case)
      beta_qr_dlp = fit.qr_dlp$beta
      mse_qr_dlp[rr] = norm(beta_qr_dlp-beta, "2")^2
      ct_qr_dlp[rr] = fit.qr_dlp$ct
      
      fit.wals_lp = wals_dlp(x,y,r0,r=subsize[rr],tau,varrho=0,alpha.case)
      beta_wals_lp = fit.wals_lp$beta
      mse_wals_lp[rr] = norm(beta_wals_lp-beta, "2")^2
      ct_wals_lp[rr] = fit.wals_lp$ct
    }    
    
    mse=cbind(mse_lp,mse_u, mse_lev,mse_qr_dlp,mse_wals_lp)
    ct=cbind(ct_g, ct_lp, ct_u, ct_lev,ct_qr_dlp,ct_wals_lp )
    
    colnames(mse) =  c(  "ALS-LP","ALS-U","ALS-LEV","QR-LP","WALS-LP")
    colnames(ct) = c("GALS", "ALS-LP", "ALS-U", "ALS-LEV","QR-LP","WALS-LP")
    #MSE
    
    return(list(MSE=mse,CT=ct))
  } 
stopImplicitCluster()
stopCluster(cl)
ee <-  ct <- list()
for (s in 1:length(sim.res)) {
  mse[[s]] <- sim.res[[s]]$MSE
  ct[[s]] <- sim.res[[s]]$CT
  
}

MSE = Reduce("+",mse)/S
MSESD <- apply(array(unlist(mse), c(length(subsize), 5, S)), c(1,2), sd)
ACT <- Reduce("+",ct)/S
ACTSD <- apply(array(unlist(ct), c(length(subsize), 6, S)), c(1,2), sd)

subsize = c(200,400,600,800,1000)
xname = "Subsample size"
xlabel = subsize
plot = DMSE.plot.r(MSE, MSESD, xlabel, ylabel=MSE, xname, yname="MSE", title="error distribution d1")



