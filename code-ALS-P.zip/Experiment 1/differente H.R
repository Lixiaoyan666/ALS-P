source("functions1.R")

N=100000
rho=0.5
case=3 #1,2
error.type=1#2,3,4
S=1000
r0=200
varrho=0.5
tau=0.3#0.5,0.7
alpha.case=1#2,3

Data = DGPfunB(N=N, rho=rho, case=case, error.type)
x = Data$X
y = Data$Y
beta = Data$beta

subsize = c(200,400,600,800,1000)

cores <- detectCores()-2
cl <- makeCluster(cores)
registerDoParallel(cl, cores=cores)
EE = foreach(i=1:S, .packages =c("matrixStats", "MASS", "glmnet","Runuran","quantreg")) %dopar%
  {
    aee = matrix(,length(subsize),2)
    
    for (rr in 1:length(subsize)) {
      
      beta_lp1 = als_dlp_TE(x, y, r0, r=subsize[rr], tau, varrho, alpha.case)
      aee_lp1 = norm(beta_lp1-beta, "2")^2
      
      beta_lp2 = als_dlp_TI(x, y, r0, r=subsize[rr], tau, varrho, alpha.case)
      aee_lp2 = norm(beta_lp2-beta, "2")^2
      
      aee[rr,]=c(aee_lp1,aee_lp2)
    }    
    colnames(aee) = c(  "ALS-LP-ME","ALS-LP-MI")
    return(aee)
  }  
stopImplicitCluster()
stopCluster(cl)

AEE = Reduce("+",EE)/S
AEESD <- apply(array(unlist(EE), c(length(subsize), 2, S)), c(1,2), sd)
  

