library("expectreg")
library("sampling")
library("ggplot2")
library("reshape2")
library("MASS") 
library("ggpubr")
library(RColorBrewer)  
library(Runuran)
library(matrixStats)
library(doParallel) 
library(doSNOW)
library(foreach)
library(glmnet)
library(dfoptim)  
library(ggforce)
library(parallel)
library(LaplacesDemon) 
library(quantreg)
library(VGAM) 


#weighted ALS by Newton-Raphson algorithm
gals.newton <- function(x,y,tau,w1,w2){
  x <- as.matrix(x)
  y <- as.vector(y)
  n <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  t1 <- proc.time()
  par0<-coef(lm(y~x+0))
  for(k in 1:1000){
    epsilon = y-x %*% par0
    f <- -tx %*% (epsilon *w1* w2* abs(tau-(epsilon<=0))) #һ�׵���
    tt <- w1*w2*abs(tau-(epsilon<=0)) 
    f_diff=tx %*% (x*c(tt)) 
    b.est <- par0-solve(f_diff)%*%f
    if(norm(b.est - par0,"2")<=1e-5) break
    par0 <- b.est
  }
  t3 <- proc.time()
  return(list(beta=b.est,inter=k,ct=(t3-t1)[3]))
}

als_u<-function(x,y,r,tau){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  #��������
  t1 <- proc.time()
  index <- 1:N
  P <- rep((r/N),N)
  decision <- rbinom(N,rep(1,N),prob=P)    
  pilot_index <- index[decision==1]
  
  xu <- x[pilot_index, ]
  yu <- y[pilot_index]
  wu <- 1/P[pilot_index]
  
  fit <-gals.newton(x=xu,y=yu,tau,1,1)
  beta <- fit$beta
  t2 <- proc.time()
  
  return(list(beta=beta,ct=(t2-t1)[3],xu=xu,yu=yu,wu=wu))
}

als_lev<-function(x,y,r,tau,varrho){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  
  ## Calculate the subsampling probability and get the subsample
  t1 <- proc.time()
  data <- data.frame(x, y)
  fit <- lm(y ~ x+0, data = data)
  leverage <- hatvalues(fit) #����ܸ˵÷�
  P <- leverage/p
  P.new <- abs((1-varrho)*P+varrho/N+1/(r+1e-6))/2-abs((1-varrho)*P+varrho/N-1/(r+1e-6))/2#ȡPi^1
  
  index <- 1:N
  eta <- rbinom(N,rep(1,N),prob=r*P.new)
  sub_index <- index[eta==1]

  xlev <- x[sub_index, ]
  ylev <- y[sub_index]
  wlev <- 1/(r*P.new[sub_index])
  
  beta = gals.newton(xlev,ylev,tau,1,wlev)$beta
  t2 <- proc.time()
  ct = (t2 - t1)[3] 
  
  return(list(beta=beta,ct=ct,xlev=xlev,ylev=ylev,wlev=wlev) )
}  

qr_dlp<-function(x,y,r0,r,tau,varrho, alpha.case){
  x <- as.matrix(x)
  y <- as.vector(y)
  p <- ncol(x)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  if(alpha.case==1){
    alpha <- diag(rep(1,p))
  }else{
    if(alpha.case==2){
      alpha <- rep(1,p)
    }else{
      alpha <- c(1,rep(0,p-1))  #rep(1/p,p)
    }
  } 
  
  ## get the  pilot sample and pilot estimator J
  t1 <- proc.time()
  index <- 1:N
  P.pilot <- rep((1/N),N)
  decision <- rbinom(N,rep(1,N),prob=r0*P.pilot)    
  pilot_index <- index[decision==1]
  xu <- x[pilot_index, ]
  yu <- y[pilot_index]
  P.u <- P.pilot[pilot_index]
  wu <- 1/(r0*P.u)  
  par0 = coef(rq(yu~xu+0,tau=tau,weights=wu))
  epsilon.u = yu-xu %*% par0
  J_hat = (t(xu)%*%xu)/length(xu)#��iid��
  
  ## Calculate the subsampling probability and get the subsample
  epsilon = y-x %*% par0
  h <- (colSums((alpha %*%ginv(J_hat) %*% tx)^2))^{1/2}
  gamma_hat <- mean(h[pilot_index])
  P <- h/(N*gamma_hat)
  P.new <- abs((1-varrho)*P+varrho/N+1/(r+1e-6))/2-abs((1-varrho)*P+varrho/N-1/(r+1e-6))/2
  
  eta <- rbinom(N,rep(1,N),prob=r*P.new)
  sub_index <- index[eta==1]
  
  xp <- x[sub_index, ]
  yp <- y[sub_index]
  P.p <- P.new[sub_index]

  xz=rbind(xu,xp)
  yz=c(yu,yp)
  P.z = (r+r0)*c(P.u,P.p)
  wz=1/P.z
  
  beta = coef(rq(yz~xz+0,tau=tau,weights=wz))
  t2 <- proc.time()
  ct = (t2 - t1)[3] 
  
  return(list(beta=beta,ct=ct,J_hat=J_hat,xz=xz,yz=yz,wz=wz) )
}  

als_dlp<-function(x,y,r0,r,tau,varrho, alpha.case){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  
  if(alpha.case==1){
    alpha <- diag(rep(1,p))
  }else{
    if(alpha.case==2){
      alpha <- rep(1,p)
    }else{
      alpha <- c(1,rep(0,p-1))  #rep(1/p,p)
    }
  } 
  ## get the pilot estimator and pilot sample
  t1 <- proc.time()
  index <- 1:N
  P.pilot <- rep((1/N),N)
  decision <- rbinom(N,rep(1,N),prob=r0*P.pilot)    
  pilot_index <- index[decision==1]
  xu <- x[pilot_index, ]
  yu <- y[pilot_index]
  P.u <- P.pilot[pilot_index]
  wu <- 1/(r0*P.u)
  par0 = gals.newton(xu, yu,  tau, 1,1)$beta
  txu <- t(xu)
  
  ## Calculate the subsampling probability and get the subsample
  epsilon = y-x %*% par0
  epsilon.u = epsilon[pilot_index]
  D_hat<-txu%*%(xu*c(abs(tau-(epsilon.u<=0))))/length(yu)  
  h <- abs(epsilon*(tau-(epsilon<=0)))* (colSums((alpha %*%ginv(D_hat) %*% tx)^2))^{1/2}
  gamma_hat <- mean(h[pilot_index])
  P <- h/(N*gamma_hat)
  P.new <- abs((1-varrho)*P+varrho/N+1/(r+1e-6))/2-abs((1-varrho)*P+varrho/N-1/(r+1e-6))/2
  eta <- rbinom(N,rep(1,N),prob=r*P.new)
  sub_index <- index[eta==1]
  
  xp <- x[sub_index, ]
  yp <- y[sub_index]
  P.p <- P.new[sub_index]

  xz=rbind(xu,xp)
  yz=c(yu,yp)
  P.z = (r+r0)*c(P.u,P.p)
  wz=1/P.z
  
  beta = gals.newton(xz,yz,tau,1,wz)$beta
  t2 <- proc.time()
  ct = (t2 - t1)[3] 
  
  return(list(beta=beta,ct=ct,xz=xz,yz=yz,wz=wz) )
}   

#initial value come from one sampling
wals_dlp<-function(x,y,r0,r,tau,varrho, alpha.case){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  
  
  if(alpha.case==1){
    alpha <- diag(rep(1,p))
  }else{
    if(alpha.case==2){
      alpha <- rep(1,p)
    }else{
      alpha <- c(1,rep(0,p-1))  
    }
  } 
  
  ## get the pilot estimator and pilot sampleһ�γ�����ó�ֵ
  t1 <- proc.time()
  index <- 1:N
  P.pilot <- rep((1/N),N)
  decision <- rbinom(N,rep(1,N),prob=r0*P.pilot)    
  pilot_index <- index[decision==1]
  xu <- x[pilot_index, ]
  yu <- y[pilot_index]
  P.u <- P.pilot[pilot_index]
  wu <- 1/(r0*P.u)  
  par0 = gals.newton(xu, yu,tau,1,1)$beta
  txu <- t(xu)
  
  ## Calculate the subsampling probability and the weight to get the subsample
  epsilon = y-x %*% par0
  epsilon.u = epsilon[pilot_index]
  D_hat<-txu%*%(xu*c(abs(tau-(epsilon.u<=0))))/length(yu)  
  weight <- exp(-(epsilon^2)*abs(tau-(epsilon<=0)))/sum(exp(-(epsilon^2)*abs(tau-(epsilon<=0)))) 
  h <- abs(weight*epsilon*(tau-(epsilon<=0)))* (rowSums((x%*%ginv(D_hat))^2))^(1/2)
  gamma_hat <- mean(h[pilot_index])
  P <- h/(N*gamma_hat)
  P.new <- abs((1-varrho)*P+varrho/N+1/(r+1e-6))/2-abs((1-varrho)*P+varrho/N-1/(r+1e-6))/2
  eta <- rbinom(N,rep(1,N),prob=r*P.new)
  sub_index <- index[eta==1]
  
  xp <- x[sub_index, ]
  yp <- y[sub_index]
  P.p <- P.new[sub_index]

  xz=rbind(xu,xp)
  yz=c(yu,yp)
  P.z = (r+r0)*c(P.u,P.p)
  w.two=1/P.z 
  w.one=c(weight[pilot_index],weight[sub_index])

  beta = gals.newton(xz,yz,tau,w.one,w.two)$beta
  t2 <- proc.time()
  ct = (t2 - t1)[3] 
  
  return(list(beta=beta,ct=ct,xz=xz,yz=yz,w.one=w.one,w.two=w.two) )
}  


# exact H
als_dlp_TE <- function(x, y, r0,r,tau,varrho, alpha.case){
  x <- as.matrix(x)
  y <- as.vector(y)
  p <- ncol(x)
  N <- length(y)
  tx <- t(x)
  
  if(alpha.case==1){
    alpha <- diag(rep(1,p))
  }else{
    if(alpha.case==2){
      alpha <- rep(1,p)
    }else{
      alpha <- c(1,rep(0,p-1))  
    }
  } 
  
  findT <- function(h,r){
    h1 <- sort(h,decreasing = TRUE)
    if(r*h1[1]/sum(h1)<=1){
      return(0)
    }
    index <- 2:r
    rough <- ((r-1):1)*h1[2:r]/rev(cumsum(rev(h1)))[2:r]
    return(min(index[rough<=1]))
  }
  
  ## get the pilot estimator and pilot sample
  index <- 1:N
  P.pilot <- rep(1/N,N)
  decision <- rbinom(N,rep(1,N),prob=r0*P.pilot)    
  pilot_index <- index[decision==1]
  xu <- x[pilot_index, ]
  yu <- y[pilot_index]
  P.u <- P.pilot[pilot_index]
  wu <- 1/(r0*P.u)
  txu <- t(xu)
  par0 = gals.newton(xu, yu, tau, 1,1)$beta
  
  #Calculate the subsampling probability with exact M (M=T)and get the subsample
  epsilon = y-x %*% par0
  D<-tx%*%(x*c(abs(tau-(epsilon<=0))))/length(y)  
  h <- abs(epsilon*(tau-(epsilon<=0)))* (colSums((alpha %*%solve(D) %*% tx)^2))^{1/2}
  T<- findT(h,r)
  if(T==0){
    P <- r*h/sum(h)
  }else{
    h0 <- sort(h,decreasing = TRUE)[T] 
    P[h<=h0] <- (r-T+1)*h[h<=h0]/sum(h[h<=h0])
    P[h>h0] <- 1
  }
  
  P <- P/r
  P.new <- abs((1-varrho)*P+varrho/N+1/(r+1e-6))/2-abs((1-varrho)*P+varrho/N-1/(r+1e-6))/2#ȡPi^1
  eta <- rbinom(N,rep(1,N),prob=r*P.new)
  sub_index <- index[eta==1]
  
  xp <- x[sub_index, ]
  yp <- y[sub_index]
  P.p <- P.new[sub_index]

  xz=rbind(xu,xp)
  yz=c(yu,yp)
  P.z = (r+r0)*c(P.u,P.p)
  wz=1/P.z
  
  beta = gals.newton(xz,yz,tau,1,wz)$beta
  
  return(beta)
}


# H=infty
als_dlp_TI <- function(x, y, r0,r,tau,varrho, alpha.case){
  x <- as.matrix(x)
  y <- as.vector(y)
  p <- ncol(x)
  N <- length(y)
  tx <- t(x)
  
  if(alpha.case==1){
    alpha <- diag(rep(1,p))
  }else{
    if(alpha.case==2){
      alpha <- rep(1,p)
    }else{
      alpha <- c(1,rep(0,p-1))  #rep(1/p,p)
    }
  } 
  
  ## get the pilot estimator and pilot sample
  index <- 1:N
  P.pilot <- rep((1/N),N)
  decision <- rbinom(N,rep(1,N),prob=r0*P.pilot)    
  pilot_index <- index[decision==1]
  xu <- x[pilot_index, ]
  yu <- y[pilot_index]
  P.u <- P.pilot[pilot_index]
  wu <- 1/(r0*P.u)
  par0 = gals.newton(xu, yu,  tau, 1,1)$beta
  
  #Calculate the subsampling probability with exact M (M=T)and get the subsample
  epsilon = y-x %*% par0
  D<-tx%*%(x*c(abs(tau-(epsilon<=0))))/length(y)  
  h <- abs(epsilon*(tau-(epsilon<=0)))* (colSums((alpha %*%solve(D) %*% tx)^2))^{1/2}
  P <- h/sum(h)
  P.new <- abs((1-varrho)*P+varrho/N+1/(r+1e-6))/2-abs((1-varrho)*P+varrho/N-1/(r+1e-6))/2
  eta <- rbinom(N,rep(1,N),prob=r*P.new)
  sub_index <- index[eta==1]
  
  xp <- x[sub_index, ]
  yp <- y[sub_index]
  P.p <- P.new[sub_index]

  xz=rbind(xu,xp)
  yz=c(yu,yp)
  P.z = (r+r0)*c(P.u,P.p)
  wz=1/P.z
  
  beta = gals.newton(xz,yz,tau,1,wz)$beta
  
  return(beta)
}

DMSE.plot.r <- function(mse, msesd, xlabel, ylabel, xname, yname, title){
  method.names = c( "ALS-LP","ALS-U","ALS-LEV","QR-LP","WALS-LP") 
  dat = data.frame(xlabel=1:length(xlabel), aee=as.vector(mse),
                   aeesd=as.vector(msesd), Method=rep(method.names, each=length(xlabel)))
  dat$Method <-factor(dat$Method, levels = method.names)
  fig = ggplot(data=dat, aes(x=xlabel, y=aee, fill=Method, shape=Method, 
                             colour=Method, group= Method))+
    geom_line(linetype=2,linewidth=0.6) + 
    scale_fill_brewer(palette = "Set1")+
    geom_point(size=2) + scale_shape_manual(values = c(15,16,17,18,0))+
    scale_x_discrete(limits = as.factor(xlabel))+ 
    theme_bw()+
    scale_y_log10()+
    xlab(xname) + ylab(yname)+
    labs(title  = title)+ 
    theme(plot.caption=element_text(colour = "black", hjust=0.5))
  fig
}

#Generate data

DGPfunB <-function(N, rho, case, error.type){
  if(case==1){
    p = 20; beta = rep(c(1,1.5),p/2)
  }else{
    if(case==2){
      p = 40; beta = rep(c(1,1.5),p/2)
    }else{
      p = 60; beta = rep(c(1,1.5),p/2)  
    }
  }
  xx =  matrix(rnorm(N*p), N, p)
  #inter = rep(1,N)
  if(rho==0){
    X=xx
    #X=cbind(inter,xx)
  }else{
    corrmat = toeplitz(rho^(0:(p-1)))
    cholmat = chol(corrmat)            #chol(A) = A'A
    X = xx %*% cholmat
    #X=cbind(inter,xx %*% cholmat)
  }
  d1=rnorm(N)
  d2=rt(N,df=3)
  d3 = rweibull(N, shape = 1.35, scale = 1)
  detla2 <- rbinom(N, 1, 0.5)
  d4=detla2*rnorm(N, -2, 1)+(1-detla2)*rnorm(N, 2, sqrt(2))
  epsilon = switch(error.type, d1, d2,d3,d4)
  Y = X%*%beta + epsilon
  return(list(Y=Y, X=X, beta=beta,p=p))
}

