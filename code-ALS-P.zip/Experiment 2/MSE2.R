 
source("functions2.R")

N=100000
rho=0.5
case=3 #1,2
error.type=1#2,3,4
S=1000
S0=100
r0=200
varrho=0.5
tau=0.3#0.5,0.7
alpha.case=1#2,3

Data = DGPfunB(N=N, rho=rho, case=case, error.type)
x = Data$X
y = Data$Y
beta = Data$beta

p <- ncol(x)

if(alpha.case==1){
  alpha <- diag(rep(1,p))
}else{
  if(alpha.case==2){
    alpha <- rep(1,p)
  }else{
    alpha <- c(1,rep(0,p-1))  #rep(1/p,p)
  }
} 

subsize = c(400,600,800,1000,1200)
fit.als_g = gals.newton(x,y,tau,1,1)

ct_g = rep(fit.als_g$ct,length(subsize))

cores <- detectCores()-2
cl <- makeCluster(cores)
registerDoParallel(cl, cores=cores)
sim.res = foreach(i=1:S, .packages =c("matrixStats", "MASS", "glmnet","Runuran","quantreg")) %dopar%
  {
    subsize = c(400,600,800,1000,1200)
    mse_lp = mse_wals_lp= rep(0,length(subsize))
    ct_lp  = ct_wals_lp = rep(0,length(subsize))
    
    for (rr in 1:length(subsize)) {
      
      fit.als_lp = als_dlp(x,y,r0,r=subsize[rr],tau,varrho,alpha.case)
      beta_lp = fit.als_lp$beta
      mse_lp[rr] = norm(beta_lp-beta, "2")^2
      ct_lp[rr] = fit.als_lp$ct
      
      
      fit.wals_lp = wals_dlp(x,y,r0,r=subsize[rr],tau,varrho=0,alpha.case,S0)
      beta_wals_lp = fit.wals_lp$beta
      mse_wals_lp[rr] = norm(beta_wals_lp-beta, "2")^2
      ct_wals_lp[rr] = fit.wals_lp$ct
    }    
    
    mse=cbind(mse_lp,mse_wals_lp)
    ct=cbind(ct_g, ct_lp, ct_wals_lp )
    
    colnames(mse)  = c(  "ALS-LP","WALS-LP")
    colnames(ct) = c("GALS", "ALS-LP","WALS-LP")

    return(list(MSE=mse,CT=ct))
  } #
stopImplicitCluster()
stopCluster(cl)
mse <- ct <- list()
for (s in 1:length(sim.res)) {
  mse[[s]] <- sim.res[[s]]$MSE
  ct[[s]] <- sim.res[[s]]$CT
}

MSE = Reduce("+",mse)/S
MSESD <- apply(array(unlist(mse), c(length(subsize), 2, S)), c(1,2), sd)
ACT <- Reduce("+",ct)/S
ACTSD <- apply(array(unlist(ct), c(length(subsize), 3, S)), c(1,2), sd)

subsize = c(400,600,800,1000,1200)
xname = "Subsample size"
xlabel = subsize
plot = DMSE.plot.r(MSE, MSESD, xlabel, ylabel=MSE, xname, yname="MSE", title="error distribution d1")

  
