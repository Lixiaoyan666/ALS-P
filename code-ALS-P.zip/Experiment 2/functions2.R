
library("expectreg")
library("sampling")
library("ggplot2")
library("reshape2")
library("MASS") 
library("ggpubr")
library(RColorBrewer)  
library(Runuran)
library(matrixStats)
library(doParallel) 
library(doSNOW)
library(foreach)
library(glmnet)
library(dfoptim) 
library(ggforce)
library(parallel)
library(LaplacesDemon) 
library(quantreg)
library(VGAM) 

gals.newton <- function(x,y,tau,w1,w2){
  x <- as.matrix(x)
  y <- as.vector(y)
  n <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  t1 <- proc.time()
  par0<-coef(lm(y~x+0))
  for(k in 1:1000){
    epsilon = y-x %*% par0
    f <- -tx %*% (epsilon *w1* w2* abs(tau-(epsilon<=0))) #һ�׵���
    tt <- w1*w2*abs(tau-(epsilon<=0)) 
    f_diff=tx %*% (x*c(tt)) 
    b.est <- par0-solve(f_diff)%*%f
    if(norm(b.est - par0,"2")<=1e-5) break
    par0 <- b.est
  }
  t3 <- proc.time()
  return(list(beta=b.est,inter=k,ct=(t3-t1)[3]))
}


als_dlp<-function(x,y,r0,r,tau,varrho, alpha.case){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  
  if(alpha.case==1){
    alpha <- diag(rep(1,p))
  }else{
    if(alpha.case==2){
      alpha <- rep(1,p)
    }else{
      alpha <- c(1,rep(0,p-1))  #rep(1/p,p)
    }
  } 
  
  ## get the pilot estimator and pilot sample
  t1 <- proc.time()
  index <- 1:N
  Pi.pilot <- rep((1/N),N)
  decision <- rbinom(N,rep(1,N),prob=r0*Pi.pilot)    
  pilot_index <- index[decision==1]
  xu <- x[pilot_index, ]
  yu <- y[pilot_index]
  Pi.u <- Pi.pilot[pilot_index]
  wu <- 1/(r0*Pi.u)
  par0 = gals.newton(xu,yu,tau,1,1)$beta
  txu=t(xu)
  
  ## Calculate the subsampling probability and get the subsample
  epsilon = y-x %*% par0
  epsilon.u = epsilon[pilot_index]
  D_hat<-txu%*%(xu*c(abs(tau-(epsilon.u<=0))))/length(yu)  
  h <- abs(epsilon*(tau-(epsilon<=0)))* (colSums((alpha %*%solve(D_hat) %*% tx)^2))^{1/2}
  gamma_hat <- mean(h[pilot_index])
  P <- h/(N*gamma_hat)
  P.new <- abs((1-varrho)*P+varrho/N+1/(r+1e-6))/2-abs((1-varrho)*P+varrho/N-1/(r+1e-6))/2
  eta <- rbinom(N,rep(1,N),prob=r*P.new)
  sub_index <- index[eta==1]
  
  xp <- x[sub_index, ]
  yp <- y[sub_index]
  P.p <- P.new[sub_index]
  wp <- 1/(r*P.p)
  
  beta = gals.newton(xp,yp,tau,1,wp)$beta
  t2 <- proc.time()
  ct = (t2 - t1)[3] 
  
  return(list(beta=beta,ct=ct,xp=xp,yp=yp,wp=wp) )
}   

#initial value come from repeated sampling
wals_dlp<-function(x,y,r0,r,tau,varrho, alpha.case,S0){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  
  
  if(alpha.case==1){
    alpha <- diag(rep(1,p))
  }else{
    if(alpha.case==2){
      alpha <- rep(1,p)
    }else{
      alpha <- c(1,rep(0,p-1))  #rep(1/p,p)
    }
  } 
  
  # ## get the pilot estimator and pilot sample
  t1 <- proc.time()
  index <- 1:N
  
  #Initial value come from repeated sampling
  par.matrix <- matrix(,p,S0)
  for (i in 1:S0) {
    pilot_index <- sample(1:N, r0, replace = TRUE)
    x.pilot <- x[pilot_index, ]
    y.pilot <- y[pilot_index]
    par.matrix[,i] = gals.newton(x.pilot,y.pilot,tau,1,1)$beta
  }
  par0 <- rowMeans(par.matrix)
  
  ## Calculate the subsampling probability and the weight to get the subsample
  epsilon = y-x %*% par0
  D_hat<-tx%*%(x*c(abs(tau-(epsilon<=0))))/length(y)  
  weight <- exp(-(epsilon^2)*abs(tau-(epsilon<=0)))/sum(exp(-(epsilon^2)*abs(tau-(epsilon<=0)))) 
  h <- abs(weight*epsilon*(tau-(epsilon<=0)))* (rowSums((x%*%solve(D_hat))^2))^(1/2)
  P <- h/sum(h)
  P.new <- abs((1-varrho)*P+varrho/N+1/(r+1e-6))/2-abs((1-varrho)*P+varrho/N-1/(r+1e-6))/2
  eta <- rbinom(N,rep(1,N),prob=r*P.new)
  sub_index <- index[eta==1]
  
  xp <- x[sub_index, ]
  yp <- y[sub_index]
  P.p <- P.new[sub_index]
  wp <- 1/(r*P.p)
  weight.p <- weight[sub_index]
  
  beta = gals.newton(xp,yp,tau,weight.p,wp)$beta
  t2 <- proc.time()
  ct = (t2 - t1)[3] 
  
  return(list(beta=beta,ct=ct,xp=xp,yp=yp,wp=wp,weight.p=weight.p) )
}  

DMSE.plot.r <- function(mse, msesd, xlabel, ylabel, xname, yname, title){
  method.names = c( "ALS-LP","WALS-LP") 
  dat = data.frame(xlabel=1:length(xlabel), aee=as.vector(mse),
                   aeesd=as.vector(msesd), Method=rep(method.names, each=length(xlabel)))
  dat$Method <-factor(dat$Method, levels = method.names)
  fig = ggplot(data=dat, aes(x=xlabel, y=aee, fill=Method, shape=Method, 
                             colour=Method, group= Method))+
    geom_line(linetype=2,linewidth=0.6) + 
    scale_fill_brewer(palette = "Set1")+
    geom_point(size=2) + scale_shape_manual(values = c(15,16))+
    scale_x_discrete(limits = as.factor(xlabel))+ 
    theme_bw()+
    scale_y_log10()+  
    xlab(xname) + ylab(yname)+
    labs(title  = title)+  
    theme(plot.caption=element_text(colour = "black", hjust=0.5))
  fig
}


#Generate data
DGPfunB <-function(N, rho, case, error.type){
  if(case==1){
    p = 20; beta = rep(c(1,1.5),p/2)
  }else{
    if(case==2){
      p = 40; beta = rep(c(1,1.5),p/2)
    }else{
      p = 60; beta = rep(c(1,1.5),p/2)  
    }
  }
  xx =  matrix(rnorm(N*p), N, p)
  #inter = rep(1,N)
  if(rho==0){
    X=xx
    #X=cbind(inter,xx)
  }else{
    corrmat = toeplitz(rho^(0:(p-1)))
    cholmat = chol(corrmat)            #chol(A) = A'A
    X = xx %*% cholmat
    #X=cbind(inter,xx %*% cholmat)
  }
  d1=rnorm(N)
  d2=rt(N,df=3)
  d3 = rweibull(N, shape = 1.35, scale = 1)
  detla2 <- rbinom(N, 1, 0.5)
  d4=detla2*rnorm(N, -2, 1)+(1-detla2)*rnorm(N, 2, sqrt(2))
  epsilon = switch(error.type, d1, d2,d3,d4)
  Y = X%*%beta + epsilon
  return(list(Y=Y, X=X, beta=beta,p=p))
}
