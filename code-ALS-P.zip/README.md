# ALS-P estimator

Poisson subsampling-based estimation for growing-dimensional expectile regression in massive data

Paper: Li X., Xia X. and Zhang Z. (2024+). Poisson subsampling-based estimation for growing-dimensional expectile regression in massive data. Submit to journal.


